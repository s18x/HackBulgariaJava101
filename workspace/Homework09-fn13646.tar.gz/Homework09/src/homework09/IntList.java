package homework09;

public class IntList {

}
